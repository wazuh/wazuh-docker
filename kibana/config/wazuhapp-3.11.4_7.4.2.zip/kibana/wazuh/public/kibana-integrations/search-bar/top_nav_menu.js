"use strict";
/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importDefault(require("react"));
const eui_1 = require("@elastic/eui");
const react_2 = require("@kbn/i18n/react");
const top_nav_menu_1 = require("plugins/kibana_react/top_nav_menu/");
const search_bar_1 = require("./search_bar");
/*
 * Top Nav Menu is a convenience wrapper component for:
 * - Top navigation menu - configured by an array of `TopNavMenuData` objects
 * - Search Bar - which includes Filter Bar \ Query Input \ Timepicker.
 *
 * See SearchBar documentation to learn more about its properties.
 *
 **/
function TopNavMenu(props) {
    function renderItems() {
        if (!props.config)
            return;
        return props.config.map((menuItem, i) => {
            return (react_1.default.createElement(eui_1.EuiFlexItem, { grow: false, key: `nav-menu-${i}` },
                react_1.default.createElement(top_nav_menu_1.TopNavMenuItem, Object.assign({}, menuItem))));
        });
    }
    function renderSearchBar() {
        // Validate presense of all required fields
        if (!props.showSearchBar || !props.savedObjectsClient)
            return;
        return (react_1.default.createElement(search_bar_1.SearchBar, { savedObjectsClient: props.savedObjectsClient, query: props.query, filters: props.filters, toasts: props.toasts, uiSettings: props.uiSettings, showQueryBar: props.showQueryBar, showQueryInput: props.showQueryInput, showFilterBar: props.showFilterBar, showDatePicker: props.showDatePicker, appName: props.appName, screenTitle: props.screenTitle, onQuerySubmit: props.onQuerySubmit, onFiltersUpdated: props.onFiltersUpdated, dateRangeFrom: props.dateRangeFrom, dateRangeTo: props.dateRangeTo, isRefreshPaused: props.isRefreshPaused, showAutoRefreshOnly: props.showAutoRefreshOnly, onRefreshChange: props.onRefreshChange, refreshInterval: props.refreshInterval, indexPatterns: props.indexPatterns, store: props.store, savedQuery: props.savedQuery, showSaveQuery: props.showSaveQuery, onClearSavedQuery: props.onClearSavedQuery, onSaved: props.onSaved, onSavedQueryUpdated: props.onSavedQueryUpdated }));
    }
    function renderLayout() {
        return (react_1.default.createElement("span", { className: "kbnTopNavMenu__wrapper" },
            react_1.default.createElement(eui_1.EuiFlexGroup, { "data-test-subj": "top-nav", justifyContent: "flexStart", gutterSize: "none", className: "kbnTopNavMenu", responsive: false }, renderItems()),
            renderSearchBar()));
    }
    return react_1.default.createElement(react_2.I18nProvider, null, renderLayout());
}
exports.TopNavMenu = TopNavMenu;
TopNavMenu.defaultProps = {
    showSearchBar: false,
    showQueryBar: true,
    showQueryInput: true,
    showDatePicker: true,
    showFilterBar: true,
    screenTitle: '',
};
