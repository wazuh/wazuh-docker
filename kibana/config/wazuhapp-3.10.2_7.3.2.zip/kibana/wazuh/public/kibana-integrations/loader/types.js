"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var QueryLanguageType;
(function (QueryLanguageType) {
    QueryLanguageType["KUERY"] = "kuery";
    QueryLanguageType["LUCENE"] = "lucene";
})(QueryLanguageType = exports.QueryLanguageType || (exports.QueryLanguageType = {}));
