"use strict";
/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const eui_1 = require("@elastic/eui");
const es_query_1 = require("@kbn/es-query");
const i18n_1 = require("@kbn/i18n");
const react_1 = __importDefault(require("react"));
const filter_operators_1 = require("plugins/data/filter/filter_bar/filter_editor/lib/filter_operators");
exports.FilterView = ({ filter, iconOnClick, onClick, ...rest }) => {
    let title = `Filter: ${getFilterDisplayText(filter)}. ${i18n_1.i18n.translate('data.filter.filterBar.moreFilterActionsMessage', {
        defaultMessage: 'Select for more filter actions.',
    })}`;
    if (es_query_1.isFilterPinned(filter)) {
        title = `${i18n_1.i18n.translate('data.filter.filterBar.pinnedFilterPrefix', {
            defaultMessage: 'Pinned',
        })} ${title}`;
    }
    if (filter.meta.disabled) {
        title = `${i18n_1.i18n.translate('data.filter.filterBar.disabledFilterPrefix', {
            defaultMessage: 'Disabled',
        })} ${title}`;
    }
    const isImplicit = typeof filter.meta.removable !== 'undefined' && !!!filter.meta.removable;
    return !isImplicit ? (react_1.default.createElement(eui_1.EuiBadge, Object.assign({ title: title, iconType: "cross", iconSide: "right", closeButtonProps: {
            // Removing tab focus on close button because the same option can be optained through the context menu
            // Also, we may want to add a `DEL` keyboard press functionality
            tabIndex: -1,
        }, iconOnClick: iconOnClick, iconOnClickAriaLabel: i18n_1.i18n.translate('data.filter.filterBar.filterItemBadgeIconAriaLabel', {
            defaultMessage: 'Delete',
        }), onClick: onClick, onClickAriaLabel: i18n_1.i18n.translate('data.filter.filterBar.filterItemBadgeAriaLabel', {
            defaultMessage: 'Filter actions',
        }) }, rest),
        react_1.default.createElement("span", null, getFilterDisplayText(filter)))) : (react_1.default.createElement(eui_1.EuiBadge, { className: rest.className },
        react_1.default.createElement("span", null, getFilterDisplayText(filter))));
};
function getFilterDisplayText(filter) {
    const prefix = filter.meta.negate
        ? ` ${i18n_1.i18n.translate('data.filter.filterBar.negatedFilterPrefix', {
            defaultMessage: 'NOT ',
        })}`
        : '';
    if (filter.meta.alias !== null) {
        return `${prefix}${filter.meta.alias}`;
    }
    switch (filter.meta.type) {
        case 'exists':
            return `${prefix}${filter.meta.key} ${filter_operators_1.existsOperator.message}`;
        case 'geo_bounding_box':
            return `${prefix}${filter.meta.key}: ${filter.meta.value}`;
        case 'geo_polygon':
            return `${prefix}${filter.meta.key}: ${filter.meta.value}`;
        case 'phrase':
            return `${prefix}${filter.meta.key}: ${filter.meta.value}`;
        case 'phrases':
            return `${prefix}${filter.meta.key} ${filter_operators_1.isOneOfOperator.message} ${filter.meta.value}`;
        case 'query_string':
            return `${prefix}${filter.meta.value}`;
        case 'range':
            return `${prefix}${filter.meta.key}: ${filter.meta.value}`;
        default:
            return `${prefix}${JSON.stringify(filter.query)}`;
    }
}
exports.getFilterDisplayText = getFilterDisplayText;
